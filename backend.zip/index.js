require("dotenv").config();
const express   = require("express");
const helmet    = require("helmet");
const cors      = require("cors");
const rateLimit = require("express-rate-limit");
const path      = require("path");

const app = express();

// ── Security ──────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));

// ── CORS ──────────────────────────────────────────────────────
app.use(cors({
  origin:         process.env.FRONTEND_URL || "*",
  credentials:    true,
  methods:        ["GET","POST","PUT","PATCH","DELETE","OPTIONS"],
  allowedHeaders: ["Content-Type","Authorization"],
}));

// ── Rate Limiting ─────────────────────────────────────────────
app.use("/api/auth/login",
  rateLimit({ windowMs: 15*60*1000, max: 10, message: "Too many login attempts" })
);
app.use("/api/", rateLimit({ windowMs: 60*1000, max: 300 }));

// ── Body Parser ───────────────────────────────────────────────
app.use(express.json({ limit: "5mb" }));
app.use(express.urlencoded({ extended: true }));

// ── Static Uploads ────────────────────────────────────────────
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// ── API Routes ────────────────────────────────────────────────
app.use("/api/auth",      require("./routes/auth"));
app.use("/api/clients",   require("./routes/clients"));
app.use("/api/invoices",  require("./routes/invoices"));
app.use("/api/payments",  require("./routes/payments"));
app.use("/api/expenses",  require("./routes/expenses"));
app.use("/api/employees", require("./routes/employees"));
app.use("/api/vault",     require("./routes/vault"));
app.use("/api/dashboard", require("./routes/dashboard"));

// ── Health Check ──────────────────────────────────────────────
app.get("/api/health", (_, res) =>
  res.json({ status: "ok", time: new Date(), version: "1.0.0" })
);

// ── Serve React Frontend (production) ────────────────────────
if (process.env.NODE_ENV === "production") {
  const distPath = path.join(__dirname, "../frontend/dist");
  app.use(express.static(distPath));
  app.get("*", (_, res) => res.sendFile(path.join(distPath, "index.html")));
}

// ── 404 for unknown API routes ────────────────────────────────
app.use("/api/*", (_, res) => res.status(404).json({ error: "Route not found" }));

// ── Global Error Handler ──────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: "Internal server error" });
});

// ── Start Server ──────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
app.listen(PORT, () =>
  console.log(`🚀 Media Mosiac ERP running on port ${PORT}`)
);
