-- ================================================================
--  Media Mosiac ERP  —  MySQL Database Schema
--  Run once in Hostinger hPanel → phpMyAdmin → Import
-- ================================================================

-- ── USERS ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100)  NOT NULL,
  email       VARCHAR(150)  NOT NULL UNIQUE,
  password    VARCHAR(255)  NOT NULL,
  role        ENUM('admin','manager','employee') DEFAULT 'employee',
  is_active   TINYINT(1)    DEFAULT 1,
  created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ── COMPANY SETTINGS ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS company (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(200),
  address      TEXT,
  city         VARCHAR(100),
  state        VARCHAR(100),
  pincode      VARCHAR(10),
  gstin        VARCHAR(20),
  pan          VARCHAR(12),
  email        VARCHAR(150),
  phone        VARCHAR(20),
  bank_name    VARCHAR(100),
  bank_ac_name VARCHAR(150),
  bank_ac_no   VARCHAR(30),
  bank_ifsc    VARCHAR(15),
  bank_swift   VARCHAR(15),
  logo_url     VARCHAR(500),
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ── CLIENTS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clients (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  company     VARCHAR(200) NOT NULL,
  contact     VARCHAR(100),
  email       VARCHAR(150),
  phone       VARCHAR(20),
  address     TEXT,
  city        VARCHAR(100),
  state       VARCHAR(100),
  country     VARCHAR(100) DEFAULT 'India',
  pincode     VARCHAR(10),
  gstin       VARCHAR(20),
  pan         VARCHAR(12),
  currency    VARCHAR(5)   DEFAULT '₹',
  status      ENUM('Active','Inactive') DEFAULT 'Active',
  notes       TEXT,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ── INVOICES ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invoices (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  invoice_number  VARCHAR(50)  NOT NULL UNIQUE,
  invoice_type    ENUM('Tax Invoice (GST)','Export Invoice','Proforma Invoice','Credit Note','Debit Note') DEFAULT 'Tax Invoice (GST)',
  client_id       INT,
  currency        VARCHAR(5)   DEFAULT '₹',
  place_of_supply VARCHAR(100),
  invoice_date    DATE         NOT NULL,
  due_date        DATE,
  payment_terms   VARCHAR(20)  DEFAULT 'Net 30',
  subtotal        DECIMAL(15,2) DEFAULT 0,
  cgst            DECIMAL(15,2) DEFAULT 0,
  sgst            DECIMAL(15,2) DEFAULT 0,
  igst            DECIMAL(15,2) DEFAULT 0,
  total_gst       DECIMAL(15,2) DEFAULT 0,
  discount        DECIMAL(15,2) DEFAULT 0,
  extra_charges   DECIMAL(15,2) DEFAULT 0,
  grand_total     DECIMAL(15,2) DEFAULT 0,
  status          ENUM('Draft','Sent','Paid','Overdue','Cancelled') DEFAULT 'Draft',
  notes           TEXT,
  terms           TEXT,
  reverse_charge  TINYINT(1)   DEFAULT 0,
  created_by      INT,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id)  REFERENCES clients(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by) REFERENCES users(id)   ON DELETE SET NULL
);

-- ── INVOICE LINE ITEMS ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invoice_items (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  invoice_id  INT          NOT NULL,
  description VARCHAR(500),
  hsn_sac     VARCHAR(20),
  qty         DECIMAL(10,2) DEFAULT 1,
  rate        DECIMAL(15,2) DEFAULT 0,
  gst_rate    DECIMAL(5,2)  DEFAULT 0,
  gst_amount  DECIMAL(15,2) DEFAULT 0,
  amount      DECIMAL(15,2) DEFAULT 0,
  sort_order  INT           DEFAULT 0,
  FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
);

-- ── CLIENT PAYMENTS ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS client_payments (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  payment_number  VARCHAR(50)  NOT NULL UNIQUE,
  client_id       INT,
  invoice_id      INT,
  invoice_ref     VARCHAR(50),
  gross_amount    DECIMAL(15,2) DEFAULT 0,
  tds_pct         DECIMAL(5,2)  DEFAULT 0,
  tds_amount      DECIMAL(15,2) DEFAULT 0,
  net_received    DECIMAL(15,2) DEFAULT 0,
  payment_date    DATE          NOT NULL,
  payment_mode    ENUM('Bank Transfer','NEFT','RTGS','Cheque','Wire Transfer','PayPal','UPI','Cash','Other') DEFAULT 'Bank Transfer',
  status          ENUM('Pending','Paid','Partial','Overdue','Cancelled') DEFAULT 'Pending',
  notes           TEXT,
  created_by      INT,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id)  REFERENCES clients(id)  ON DELETE SET NULL,
  FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by) REFERENCES users(id)    ON DELETE SET NULL
);

-- ── EXPENSES ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS expenses (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  category     VARCHAR(100) NOT NULL,
  description  VARCHAR(500),
  amount       DECIMAL(15,2) NOT NULL,
  expense_date DATE          NOT NULL,
  vendor       VARCHAR(200),
  invoice_ref  VARCHAR(100),
  receipt_url  VARCHAR(500),
  status       ENUM('Pending','Approved','Rejected') DEFAULT 'Pending',
  approved_by  INT,
  notes        TEXT,
  created_by   INT,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by)  REFERENCES users(id) ON DELETE SET NULL
);

-- ── EMPLOYEES ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS employees (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(150) NOT NULL,
  email        VARCHAR(150),
  phone        VARCHAR(20),
  role         VARCHAR(100),
  department   VARCHAR(100),
  join_date    DATE,
  pan          VARCHAR(12),
  aadhaar      VARCHAR(20),
  bank_ac_name VARCHAR(150),
  bank_ac_no   VARCHAR(30),
  bank_ifsc    VARCHAR(15),
  basic        DECIMAL(12,2) DEFAULT 0,
  hra          DECIMAL(12,2) DEFAULT 0,
  status       ENUM('Active','Inactive') DEFAULT 'Active',
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ── PAYROLL ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payroll (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  employee_id INT          NOT NULL,
  month       VARCHAR(7)   NOT NULL,
  basic       DECIMAL(12,2) DEFAULT 0,
  hra         DECIMAL(12,2) DEFAULT 0,
  bonus       DECIMAL(12,2) DEFAULT 0,
  deductions  DECIMAL(12,2) DEFAULT 0,
  tds         DECIMAL(12,2) DEFAULT 0,
  net_pay     DECIMAL(12,2) DEFAULT 0,
  status      ENUM('Pending','Paid') DEFAULT 'Pending',
  paid_on     DATE,
  notes       TEXT,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
  UNIQUE KEY unique_emp_month (employee_id, month)
);

-- ── PASSWORD VAULT ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS vault (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  title        VARCHAR(200) NOT NULL,
  url          VARCHAR(500),
  username     VARCHAR(200),
  password_enc TEXT         NOT NULL,
  category     VARCHAR(100) DEFAULT 'General',
  notes        TEXT,
  created_by   INT,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ── PERFORMANCE INDEXES ───────────────────────────────────────
CREATE INDEX idx_invoices_client   ON invoices(client_id);
CREATE INDEX idx_invoices_status   ON invoices(status);
CREATE INDEX idx_invoices_date     ON invoices(invoice_date);
CREATE INDEX idx_payments_client   ON client_payments(client_id);
CREATE INDEX idx_payments_date     ON client_payments(payment_date);
CREATE INDEX idx_payments_status   ON client_payments(status);
CREATE INDEX idx_expenses_date     ON expenses(expense_date);
CREATE INDEX idx_expenses_category ON expenses(category);
CREATE INDEX idx_payroll_month     ON payroll(month);

-- ── DEFAULT ADMIN USER ────────────────────────────────────────
-- Password is: Admin@1234
-- CHANGE THIS IMMEDIATELY AFTER FIRST LOGIN
INSERT INTO users (name, email, password, role) VALUES
('Admin', 'admin@mediamosiac.com',
 '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'admin');

-- ── DEFAULT COMPANY SETTINGS ─────────────────────────────────
INSERT INTO company
  (name, address, city, state, gstin, pan, email, phone,
   bank_name, bank_ac_name, bank_ac_no, bank_ifsc, bank_swift)
VALUES
  ('Media Mosiac OPC Private Limited',
   'D-152, Lajpat Nagar', 'Delhi', 'Delhi',
   '07AARCM4701C1ZN', 'AARCM4701C',
   'asim@mediamosiac.com', '+91 98101 22333',
   'Jammu and Kashmir Bank',
   'MEDIA MOSIAC OPC PRIVATE LIMITED',
   '0459010100001044', 'JAKA0GKLASH', 'JAKAINBBSRI');
