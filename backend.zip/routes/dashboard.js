const router = require("express").Router();
const db   = require("../db/connection");
const auth = require("../middleware/auth");

// GET /api/dashboard/stats
router.get("/stats", auth, async (req, res) => {
  try {
    const [[rev]]   = await db.query("SELECT COALESCE(SUM(grand_total),0) t FROM invoices WHERE status IN ('Paid','Sent') AND YEAR(invoice_date)=YEAR(NOW())");
    const [[paid]]  = await db.query("SELECT COALESCE(SUM(grand_total),0) t FROM invoices WHERE status='Paid' AND YEAR(invoice_date)=YEAR(NOW())");
    const [[recv]]  = await db.query("SELECT COALESCE(SUM(grand_total),0) t FROM invoices WHERE status='Sent'");
    const [[exp]]   = await db.query("SELECT COALESCE(SUM(amount),0) t FROM expenses WHERE status='Approved' AND YEAR(expense_date)=YEAR(NOW())");
    const [[gst]]   = await db.query("SELECT COALESCE(SUM(total_gst),0) t FROM invoices WHERE MONTH(invoice_date)=MONTH(NOW()) AND YEAR(invoice_date)=YEAR(NOW())");
    const [[tds]]   = await db.query("SELECT COALESCE(SUM(tds_amount),0) t FROM client_payments WHERE YEAR(payment_date)=YEAR(NOW())");
    const [[cl]]    = await db.query("SELECT COUNT(*) t FROM clients WHERE status='Active'");
    const [[pend]]  = await db.query("SELECT COUNT(*) t FROM invoices WHERE status IN ('Draft','Sent')");
    const [[emp]]   = await db.query("SELECT COUNT(*) t FROM employees WHERE status='Active'");
    res.json({
      total_revenue:    rev.t,
      total_paid:       paid.t,
      receivables:      recv.t,
      net_profit:       paid.t - exp.t,
      total_expenses:   exp.t,
      gst_payable:      gst.t,
      tds_deducted_ytd: tds.t,
      active_clients:   cl.t,
      pending_invoices: pend.t,
      active_employees: emp.t,
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/dashboard/monthly  — revenue + expenses last 12 months
router.get("/monthly", auth, async (req, res) => {
  try {
    const [rev] = await db.query(
      `SELECT DATE_FORMAT(invoice_date,'%Y-%m') month, SUM(grand_total) revenue
       FROM invoices WHERE invoice_date>=DATE_SUB(NOW(),INTERVAL 12 MONTH)
       GROUP BY month ORDER BY month`
    );
    const [exps] = await db.query(
      `SELECT DATE_FORMAT(expense_date,'%Y-%m') month, SUM(amount) expenses
       FROM expenses WHERE expense_date>=DATE_SUB(NOW(),INTERVAL 12 MONTH)
       GROUP BY month ORDER BY month`
    );
    res.json({ revenue: rev, expenses: exps });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/dashboard/top-clients
router.get("/top-clients", auth, async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT c.company, SUM(i.grand_total) total
       FROM invoices i JOIN clients c ON i.client_id=c.id
       WHERE i.status IN ('Paid','Sent') AND YEAR(i.invoice_date)=YEAR(NOW())
       GROUP BY c.id ORDER BY total DESC LIMIT 5`
    );
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/dashboard/company
router.get("/company", auth, async (req, res) => {
  const [r] = await db.query("SELECT * FROM company LIMIT 1");
  res.json(r[0] || {});
});

// PUT /api/dashboard/company  (admin only)
router.put("/company", auth, async (req, res) => {
  try {
    if (req.user.role !== "admin") return res.status(403).json({ error:"Admin only" });
    const { name,address,city,state,pincode,gstin,pan,email,phone,
            bank_name,bank_ac_name,bank_ac_no,bank_ifsc,bank_swift } = req.body;
    const [existing] = await db.query("SELECT id FROM company LIMIT 1");
    if (existing.length) {
      await db.query(
        `UPDATE company SET name=?,address=?,city=?,state=?,pincode=?,gstin=?,pan=?,
         email=?,phone=?,bank_name=?,bank_ac_name=?,bank_ac_no=?,bank_ifsc=?,bank_swift=? WHERE id=?`,
        [name,address,city,state,pincode,gstin,pan,email,phone,
         bank_name,bank_ac_name,bank_ac_no,bank_ifsc,bank_swift,existing[0].id]
      );
    } else {
      await db.query(
        `INSERT INTO company (name,address,city,state,pincode,gstin,pan,email,phone,
          bank_name,bank_ac_name,bank_ac_no,bank_ifsc,bank_swift) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [name,address,city,state,pincode,gstin,pan,email,phone,bank_name,bank_ac_name,bank_ac_no,bank_ifsc,bank_swift]
      );
    }
    res.json({ message:"Saved" });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
