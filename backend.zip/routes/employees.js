const router = require("express").Router();
const db   = require("../db/connection");
const auth = require("../middleware/auth");

// ── EMPLOYEES ────────────────────────────────────────────────
router.get("/", auth, async (req, res) => {
  const { status, department } = req.query;
  let sql = "SELECT * FROM employees WHERE 1=1";
  const p = [];
  if (status)     { sql+=" AND status=?";     p.push(status); }
  if (department) { sql+=" AND department=?"; p.push(department); }
  sql += " ORDER BY name";
  const [rows] = await db.query(sql, p);
  res.json(rows);
});

router.get("/:id", auth, async (req, res) => {
  const [r] = await db.query("SELECT * FROM employees WHERE id=?", [req.params.id]);
  if (!r.length) return res.status(404).json({ error:"Not found" });
  res.json(r[0]);
});

router.post("/", auth, async (req, res) => {
  try {
    const { name,email,phone,role,department,join_date,pan,aadhaar,
            bank_ac_name,bank_ac_no,bank_ifsc,basic,hra } = req.body;
    if (!name) return res.status(400).json({ error:"Name required" });
    const [result] = await db.query(
      `INSERT INTO employees (name,email,phone,role,department,join_date,pan,aadhaar,
         bank_ac_name,bank_ac_no,bank_ifsc,basic,hra) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [name,email,phone,role,department,join_date,pan,aadhaar,bank_ac_name,bank_ac_no,bank_ifsc,basic||0,hra||0]
    );
    const [rows] = await db.query("SELECT * FROM employees WHERE id=?", [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.put("/:id", auth, async (req, res) => {
  try {
    const { name,email,phone,role,department,join_date,pan,aadhaar,
            bank_ac_name,bank_ac_no,bank_ifsc,basic,hra,status } = req.body;
    await db.query(
      `UPDATE employees SET name=?,email=?,phone=?,role=?,department=?,join_date=?,
       pan=?,aadhaar=?,bank_ac_name=?,bank_ac_no=?,bank_ifsc=?,basic=?,hra=?,
       status=?,updated_at=NOW() WHERE id=?`,
      [name,email,phone,role,department,join_date,pan,aadhaar,bank_ac_name,
       bank_ac_no,bank_ifsc,basic,hra,status,req.params.id]
    );
    const [rows] = await db.query("SELECT * FROM employees WHERE id=?", [req.params.id]);
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.delete("/:id", auth, async (req, res) => {
  await db.query("DELETE FROM employees WHERE id=?", [req.params.id]);
  res.json({ message:"Deleted" });
});

// ── PAYROLL ──────────────────────────────────────────────────
router.get("/:id/payroll", auth, async (req, res) => {
  const [rows] = await db.query(
    "SELECT * FROM payroll WHERE employee_id=? ORDER BY month DESC", [req.params.id]
  );
  res.json(rows);
});

router.post("/:id/payroll", auth, async (req, res) => {
  try {
    const { month,basic,hra,bonus,deductions,tds,net_pay,status,paid_on,notes } = req.body;
    if (!month) return res.status(400).json({ error:"month required" });
    await db.query(
      `INSERT INTO payroll (employee_id,month,basic,hra,bonus,deductions,tds,net_pay,status,paid_on,notes)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)
       ON DUPLICATE KEY UPDATE basic=VALUES(basic),hra=VALUES(hra),bonus=VALUES(bonus),
         deductions=VALUES(deductions),tds=VALUES(tds),net_pay=VALUES(net_pay),
         status=VALUES(status),paid_on=VALUES(paid_on)`,
      [req.params.id,month,basic||0,hra||0,bonus||0,deductions||0,tds||0,
       net_pay||0,status||"Pending",paid_on,notes]
    );
    res.status(201).json({ message:"Saved" });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/employees/payroll/bulk?month=2026-05
router.get("/payroll/bulk", auth, async (req, res) => {
  const { month } = req.query;
  if (!month) return res.status(400).json({ error:"month required" });
  const [rows] = await db.query(
    `SELECT p.*,e.name,e.role,e.department FROM payroll p
     JOIN employees e ON p.employee_id=e.id WHERE p.month=?`, [month]
  );
  res.json(rows);
});

module.exports = router;
