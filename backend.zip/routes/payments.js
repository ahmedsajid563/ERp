const router = require("express").Router();
const db   = require("../db/connection");
const auth = require("../middleware/auth");

router.get("/", auth, async (req, res) => {
  try {
    const { search, status, client_id, tds_only, from, to } = req.query;
    let sql = `SELECT cp.*,c.company as client_name
               FROM client_payments cp
               LEFT JOIN clients c ON cp.client_id=c.id WHERE 1=1`;
    const p = [];
    if (search)   { sql+=" AND (cp.payment_number LIKE ? OR c.company LIKE ? OR cp.invoice_ref LIKE ?)"; const s=`%${search}%`; p.push(s,s,s); }
    if (status)   { sql+=" AND cp.status=?"; p.push(status); }
    if (client_id){ sql+=" AND cp.client_id=?"; p.push(client_id); }
    if (tds_only==="1") { sql+=" AND cp.tds_amount>0"; }
    if (from)     { sql+=" AND cp.payment_date>=?"; p.push(from); }
    if (to)       { sql+=" AND cp.payment_date<=?"; p.push(to); }
    sql += " ORDER BY cp.created_at DESC";
    const [rows] = await db.query(sql, p);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get("/tds-summary", auth, async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT c.company, SUM(cp.gross_amount) as gross,
              SUM(cp.tds_amount) as tds, SUM(cp.net_received) as net
       FROM client_payments cp
       JOIN clients c ON cp.client_id=c.id
       WHERE cp.tds_amount>0
       GROUP BY c.id ORDER BY tds DESC`
    );
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get("/:id", auth, async (req, res) => {
  const [r] = await db.query(
    `SELECT cp.*,c.company as client_name FROM client_payments cp
     LEFT JOIN clients c ON cp.client_id=c.id WHERE cp.id=?`, [req.params.id]
  );
  if (!r.length) return res.status(404).json({ error:"Not found" });
  res.json(r[0]);
});

router.post("/", auth, async (req, res) => {
  try {
    const { payment_number,client_id,invoice_id,invoice_ref,gross_amount,
            tds_pct,tds_amount,net_received,payment_date,payment_mode,status,notes } = req.body;
    if (!payment_date) return res.status(400).json({ error:"payment_date required" });
    const pNum = payment_number || `PAY-${Date.now()}`;
    const [result] = await db.query(
      `INSERT INTO client_payments
         (payment_number,client_id,invoice_id,invoice_ref,gross_amount,tds_pct,
          tds_amount,net_received,payment_date,payment_mode,status,notes,created_by)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [pNum,client_id,invoice_id||null,invoice_ref,gross_amount,tds_pct||0,
       tds_amount||0,net_received,payment_date,payment_mode||"Bank Transfer",
       status||"Pending",notes,req.user.id]
    );
    const [rows] = await db.query("SELECT * FROM client_payments WHERE id=?", [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (e) {
    if (e.code==="ER_DUP_ENTRY") return res.status(409).json({ error:"Payment number already exists" });
    res.status(500).json({ error: e.message });
  }
});

router.put("/:id", auth, async (req, res) => {
  try {
    const { client_id,invoice_id,invoice_ref,gross_amount,tds_pct,
            tds_amount,net_received,payment_date,payment_mode,status,notes } = req.body;
    await db.query(
      `UPDATE client_payments SET client_id=?,invoice_id=?,invoice_ref=?,gross_amount=?,
       tds_pct=?,tds_amount=?,net_received=?,payment_date=?,payment_mode=?,
       status=?,notes=?,updated_at=NOW() WHERE id=?`,
      [client_id,invoice_id||null,invoice_ref,gross_amount,tds_pct||0,tds_amount||0,
       net_received,payment_date,payment_mode,status,notes,req.params.id]
    );
    res.json({ message:"Updated" });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.delete("/:id", auth, async (req, res) => {
  await db.query("DELETE FROM client_payments WHERE id=?", [req.params.id]);
  res.json({ message:"Deleted" });
});

module.exports = router;
