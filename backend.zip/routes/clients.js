const router = require("express").Router();
const db   = require("../db/connection");
const auth = require("../middleware/auth");

router.get("/", auth, async (req, res) => {
  try {
    const { search, status } = req.query;
    let sql = "SELECT * FROM clients WHERE 1=1";
    const p = [];
    if (search) { sql += " AND (company LIKE ? OR contact LIKE ? OR email LIKE ?)"; const s=`%${search}%`; p.push(s,s,s); }
    if (status) { sql += " AND status=?"; p.push(status); }
    sql += " ORDER BY created_at DESC";
    const [rows] = await db.query(sql, p);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get("/:id", auth, async (req, res) => {
  const [r] = await db.query("SELECT * FROM clients WHERE id=?", [req.params.id]);
  if (!r.length) return res.status(404).json({ error: "Not found" });
  res.json(r[0]);
});

router.post("/", auth, async (req, res) => {
  try {
    const { company,contact,email,phone,address,city,state,country,pincode,gstin,pan,currency,status,notes } = req.body;
    if (!company) return res.status(400).json({ error: "Company name required" });
    const [result] = await db.query(
      `INSERT INTO clients (company,contact,email,phone,address,city,state,country,pincode,gstin,pan,currency,status,notes)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [company,contact,email,phone,address,city,state,country||"India",pincode,gstin,pan,currency||"₹",status||"Active",notes]
    );
    const [rows] = await db.query("SELECT * FROM clients WHERE id=?", [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.put("/:id", auth, async (req, res) => {
  try {
    const { company,contact,email,phone,address,city,state,country,pincode,gstin,pan,currency,status,notes } = req.body;
    await db.query(
      `UPDATE clients SET company=?,contact=?,email=?,phone=?,address=?,city=?,state=?,
       country=?,pincode=?,gstin=?,pan=?,currency=?,status=?,notes=?,updated_at=NOW() WHERE id=?`,
      [company,contact,email,phone,address,city,state,country,pincode,gstin,pan,currency,status,notes,req.params.id]
    );
    const [rows] = await db.query("SELECT * FROM clients WHERE id=?", [req.params.id]);
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.delete("/:id", auth, async (req, res) => {
  await db.query("DELETE FROM clients WHERE id=?", [req.params.id]);
  res.json({ message: "Deleted" });
});

module.exports = router;
