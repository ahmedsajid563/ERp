const router = require("express").Router();
const db   = require("../db/connection");
const auth = require("../middleware/auth");

router.get("/", auth, async (req, res) => {
  try {
    const { category, status, from, to } = req.query;
    let sql = "SELECT * FROM expenses WHERE 1=1";
    const p = [];
    if (category) { sql+=" AND category=?"; p.push(category); }
    if (status)   { sql+=" AND status=?";   p.push(status); }
    if (from)     { sql+=" AND expense_date>=?"; p.push(from); }
    if (to)       { sql+=" AND expense_date<=?"; p.push(to); }
    sql += " ORDER BY expense_date DESC";
    const [rows] = await db.query(sql, p);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get("/:id", auth, async (req, res) => {
  const [r] = await db.query("SELECT * FROM expenses WHERE id=?", [req.params.id]);
  if (!r.length) return res.status(404).json({ error:"Not found" });
  res.json(r[0]);
});

router.post("/", auth, async (req, res) => {
  try {
    const { category,description,amount,expense_date,vendor,invoice_ref,status,notes } = req.body;
    if (!category||!amount||!expense_date)
      return res.status(400).json({ error:"category, amount, expense_date required" });
    const [result] = await db.query(
      `INSERT INTO expenses (category,description,amount,expense_date,vendor,invoice_ref,status,notes,created_by)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [category,description,amount,expense_date,vendor,invoice_ref,status||"Pending",notes,req.user.id]
    );
    const [rows] = await db.query("SELECT * FROM expenses WHERE id=?", [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.put("/:id", auth, async (req, res) => {
  try {
    const { category,description,amount,expense_date,vendor,invoice_ref,status,notes } = req.body;
    await db.query(
      `UPDATE expenses SET category=?,description=?,amount=?,expense_date=?,
       vendor=?,invoice_ref=?,status=?,notes=?,updated_at=NOW() WHERE id=?`,
      [category,description,amount,expense_date,vendor,invoice_ref,status,notes,req.params.id]
    );
    const [rows] = await db.query("SELECT * FROM expenses WHERE id=?", [req.params.id]);
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.delete("/:id", auth, async (req, res) => {
  await db.query("DELETE FROM expenses WHERE id=?", [req.params.id]);
  res.json({ message:"Deleted" });
});

module.exports = router;
