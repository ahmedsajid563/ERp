const router   = require("express").Router();
const db       = require("../db/connection");
const auth     = require("../middleware/auth");
const CryptoJS = require("crypto-js");

const enc = t  => CryptoJS.AES.encrypt(t, process.env.VAULT_KEY).toString();
const dec = c  => { try { return CryptoJS.AES.decrypt(c, process.env.VAULT_KEY).toString(CryptoJS.enc.Utf8); } catch { return ""; } };

router.get("/", auth, async (req, res) => {
  try {
    const { category, search } = req.query;
    let sql = "SELECT id,title,url,username,category,notes,created_at,updated_at FROM vault WHERE created_by=?";
    const p = [req.user.id];
    if (category) { sql+=" AND category=?"; p.push(category); }
    if (search)   { sql+=" AND (title LIKE ? OR username LIKE ?)"; const s=`%${search}%`; p.push(s,s); }
    sql += " ORDER BY title";
    const [rows] = await db.query(sql, p);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Reveal password — separate endpoint
router.get("/:id/reveal", auth, async (req, res) => {
  const [r] = await db.query(
    "SELECT password_enc FROM vault WHERE id=? AND created_by=?", [req.params.id, req.user.id]
  );
  if (!r.length) return res.status(404).json({ error:"Not found" });
  res.json({ password: dec(r[0].password_enc) });
});

router.post("/", auth, async (req, res) => {
  try {
    const { title,url,username,password,category,notes } = req.body;
    if (!title||!password) return res.status(400).json({ error:"title and password required" });
    const [result] = await db.query(
      "INSERT INTO vault (title,url,username,password_enc,category,notes,created_by) VALUES (?,?,?,?,?,?,?)",
      [title,url,username,enc(password),category||"General",notes,req.user.id]
    );
    res.status(201).json({ id:result.insertId, title, url, username, category, notes });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.put("/:id", auth, async (req, res) => {
  try {
    const { title,url,username,password,category,notes } = req.body;
    if (password) {
      await db.query(
        "UPDATE vault SET title=?,url=?,username=?,password_enc=?,category=?,notes=?,updated_at=NOW() WHERE id=? AND created_by=?",
        [title,url,username,enc(password),category,notes,req.params.id,req.user.id]
      );
    } else {
      await db.query(
        "UPDATE vault SET title=?,url=?,username=?,category=?,notes=?,updated_at=NOW() WHERE id=? AND created_by=?",
        [title,url,username,category,notes,req.params.id,req.user.id]
      );
    }
    res.json({ message:"Updated" });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.delete("/:id", auth, async (req, res) => {
  await db.query("DELETE FROM vault WHERE id=? AND created_by=?", [req.params.id, req.user.id]);
  res.json({ message:"Deleted" });
});

module.exports = router;
