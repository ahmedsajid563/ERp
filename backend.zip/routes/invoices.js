const router = require("express").Router();
const db   = require("../db/connection");
const auth = require("../middleware/auth");

router.get("/", auth, async (req, res) => {
  try {
    const { search, status, from, to } = req.query;
    let sql = `SELECT i.*,c.company as client_name,c.email as client_email,c.gstin as client_gstin
               FROM invoices i LEFT JOIN clients c ON i.client_id=c.id WHERE 1=1`;
    const p = [];
    if (search) { sql+=" AND (i.invoice_number LIKE ? OR c.company LIKE ?)"; const s=`%${search}%`; p.push(s,s); }
    if (status) { sql+=" AND i.status=?"; p.push(status); }
    if (from)   { sql+=" AND i.invoice_date>=?"; p.push(from); }
    if (to)     { sql+=" AND i.invoice_date<=?"; p.push(to); }
    sql += " ORDER BY i.created_at DESC";
    const [rows] = await db.query(sql, p);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get("/:id", auth, async (req, res) => {
  try {
    const [inv] = await db.query(
      `SELECT i.*,c.company as client_name,c.contact as client_contact,
              c.email as client_email,c.address as client_address,
              c.city as client_city,c.gstin as client_gstin
       FROM invoices i LEFT JOIN clients c ON i.client_id=c.id WHERE i.id=?`, [req.params.id]
    );
    if (!inv.length) return res.status(404).json({ error: "Not found" });
    const [items] = await db.query(
      "SELECT * FROM invoice_items WHERE invoice_id=? ORDER BY sort_order", [req.params.id]
    );
    res.json({ ...inv[0], items });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post("/", auth, async (req, res) => {
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const {
      invoice_number,invoice_type,client_id,currency,place_of_supply,
      invoice_date,due_date,payment_terms,subtotal,cgst,sgst,igst,
      total_gst,discount,extra_charges,grand_total,status,notes,terms,
      reverse_charge, items=[]
    } = req.body;

    const [result] = await conn.query(
      `INSERT INTO invoices (invoice_number,invoice_type,client_id,currency,place_of_supply,
        invoice_date,due_date,payment_terms,subtotal,cgst,sgst,igst,total_gst,discount,
        extra_charges,grand_total,status,notes,terms,reverse_charge,created_by)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [invoice_number,invoice_type,client_id,currency,place_of_supply,invoice_date,
       due_date,payment_terms,subtotal,cgst,sgst,igst,total_gst,discount,extra_charges,
       grand_total,status||"Draft",notes,terms,reverse_charge?1:0,req.user.id]
    );
    const invId = result.insertId;
    for (let i=0; i<items.length; i++) {
      const it = items[i];
      const amt = (parseFloat(it.qty)||0) * (parseFloat(it.rate)||0);
      const gstAmt = amt * (parseFloat(it.gst_rate)||0) / 100;
      await conn.query(
        `INSERT INTO invoice_items (invoice_id,description,hsn_sac,qty,rate,gst_rate,gst_amount,amount,sort_order)
         VALUES (?,?,?,?,?,?,?,?,?)`,
        [invId,it.description,it.hsn_sac,it.qty,it.rate,it.gst_rate,gstAmt,amt,i]
      );
    }
    await conn.commit();
    res.status(201).json({ id: invId, invoice_number });
  } catch (e) {
    await conn.rollback();
    if (e.code==="ER_DUP_ENTRY") return res.status(409).json({ error:"Invoice number already exists" });
    res.status(500).json({ error: e.message });
  } finally { conn.release(); }
});

router.put("/:id", auth, async (req, res) => {
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const {
      invoice_type,client_id,currency,place_of_supply,invoice_date,due_date,
      payment_terms,subtotal,cgst,sgst,igst,total_gst,discount,extra_charges,
      grand_total,status,notes,terms,reverse_charge,items=[]
    } = req.body;
    await conn.query(
      `UPDATE invoices SET invoice_type=?,client_id=?,currency=?,place_of_supply=?,
       invoice_date=?,due_date=?,payment_terms=?,subtotal=?,cgst=?,sgst=?,igst=?,
       total_gst=?,discount=?,extra_charges=?,grand_total=?,status=?,notes=?,
       terms=?,reverse_charge=?,updated_at=NOW() WHERE id=?`,
      [invoice_type,client_id,currency,place_of_supply,invoice_date,due_date,
       payment_terms,subtotal,cgst,sgst,igst,total_gst,discount,extra_charges,
       grand_total,status,notes,terms,reverse_charge?1:0,req.params.id]
    );
    await conn.query("DELETE FROM invoice_items WHERE invoice_id=?", [req.params.id]);
    for (let i=0; i<items.length; i++) {
      const it = items[i];
      const amt = (parseFloat(it.qty)||0)*(parseFloat(it.rate)||0);
      const gstAmt = amt*(parseFloat(it.gst_rate)||0)/100;
      await conn.query(
        `INSERT INTO invoice_items (invoice_id,description,hsn_sac,qty,rate,gst_rate,gst_amount,amount,sort_order)
         VALUES (?,?,?,?,?,?,?,?,?)`,
        [req.params.id,it.description,it.hsn_sac,it.qty,it.rate,it.gst_rate,gstAmt,amt,i]
      );
    }
    await conn.commit();
    res.json({ message: "Updated" });
  } catch (e) { await conn.rollback(); res.status(500).json({ error: e.message }); }
  finally { conn.release(); }
});

router.delete("/:id", auth, async (req, res) => {
  await db.query("DELETE FROM invoices WHERE id=?", [req.params.id]);
  res.json({ message: "Deleted" });
});

router.patch("/:id/status", auth, async (req, res) => {
  await db.query("UPDATE invoices SET status=?,updated_at=NOW() WHERE id=?",
    [req.body.status, req.params.id]);
  res.json({ message: "Status updated" });
});

module.exports = router;
