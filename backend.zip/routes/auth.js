const router = require("express").Router();
const bcrypt = require("bcryptjs");
const jwt    = require("jsonwebtoken");
const db     = require("../db/connection");
const auth   = require("../middleware/auth");

// POST /api/auth/login
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ error: "Email and password required" });

    const [rows] = await db.query(
      "SELECT * FROM users WHERE email=? AND is_active=1", [email]
    );
    if (!rows.length) return res.status(401).json({ error: "Invalid credentials" });

    const ok = await bcrypt.compare(password, rows[0].password);
    if (!ok) return res.status(401).json({ error: "Invalid credentials" });

    const u = rows[0];
    const token = jwt.sign(
      { id: u.id, email: u.email, role: u.role, name: u.name },
      process.env.JWT_SECRET, { expiresIn: "7d" }
    );
    res.json({ token, user: { id:u.id, name:u.name, email:u.email, role:u.role } });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/auth/me
router.get("/me", auth, async (req, res) => {
  const [r] = await db.query(
    "SELECT id,name,email,role,created_at FROM users WHERE id=?", [req.user.id]
  );
  res.json(r[0] || {});
});

// POST /api/auth/register  (admin only)
router.post("/register", auth, async (req, res) => {
  try {
    if (req.user.role !== "admin")
      return res.status(403).json({ error: "Admin only" });
    const { name, email, password, role } = req.body;
    const hash = await bcrypt.hash(password, 10);
    const [result] = await db.query(
      "INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)",
      [name, email, hash, role || "employee"]
    );
    res.status(201).json({ id: result.insertId, name, email, role: role||"employee" });
  } catch (e) {
    if (e.code === "ER_DUP_ENTRY")
      return res.status(409).json({ error: "Email already exists" });
    res.status(500).json({ error: e.message });
  }
});

// PUT /api/auth/change-password
router.put("/change-password", auth, async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body;
    const [r] = await db.query("SELECT password FROM users WHERE id=?", [req.user.id]);
    if (!await bcrypt.compare(oldPassword, r[0].password))
      return res.status(400).json({ error: "Old password incorrect" });
    await db.query("UPDATE users SET password=? WHERE id=?",
      [await bcrypt.hash(newPassword, 10), req.user.id]);
    res.json({ message: "Password changed" });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
